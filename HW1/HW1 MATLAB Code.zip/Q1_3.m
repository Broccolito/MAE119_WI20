
omega = 32.87;
delta = -20.34;
sigma = 60.25;

theta =acosd(cosd(omega)*cosd(delta)*cosd(sigma)+sind(omega)*sind(delta));
% theta = 78.3380;

alphas = 90 - theta;
% alphas = 11.6620;



